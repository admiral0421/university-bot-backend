# Entry point for Telegram bot
print('Bot is running')